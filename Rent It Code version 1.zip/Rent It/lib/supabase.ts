import { createClient } from '@supabase/supabase-js'

// Supabase Konfiguration - diese Werte müssen Sie in Ihrer .env.local Datei setzen
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Erstellt den Supabase Client für die Frontend-Anwendung
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Hilfsfunktion zum Abrufen des aktuellen Benutzers
export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error) {
    console.error('Fehler beim Abrufen des Benutzers:', error)
    return null
  }
  return user
}

// Hilfsfunktion zum Abrufen der Benutzer-Session
export const getSession = async () => {
  const { data: { session }, error } = await supabase.auth.getSession()
  if (error) {
    console.error('Fehler beim Abrufen der Session:', error)
    return null
  }
  return session
}

