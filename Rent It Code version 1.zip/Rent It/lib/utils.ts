import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

// Hilfsfunktion zum Zusammenführen von Tailwind CSS-Klassen
// Verhindert Konflikte und optimiert die finale CSS-Ausgabe
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Hilfsfunktion zum Formatieren von Preisen
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR',
  }).format(price)
}

// Hilfsfunktion zum Formatieren von Datumsangaben
export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('de-DE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(new Date(date))
}

// Hilfsfunktion zum Berechnen der Anzahl der Tage zwischen zwei Daten
export function calculateDays(startDate: string | Date, endDate: string | Date): number {
  const start = new Date(startDate)
  const end = new Date(endDate)
  const diffTime = Math.abs(end.getTime() - start.getTime())
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
}

// Hilfsfunktion zum Generieren einer zufälligen ID
export function generateId(): string {
  return Math.random().toString(36).substr(2, 9)
}
