'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/AuthProvider'
import { motion } from 'framer-motion'
import { 
  MapPin, 
  Euro, 
  User, 
  Calendar, 
  Clock, 
  Star, 
  MessageCircle,
  Phone,
  Mail,
  ArrowLeft,
  Heart,
  Share2,
  AlertCircle,
  CheckCircle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase'
import { formatPrice, formatDate, calculateDays } from '@/lib/utils'

// Typen für die Daten
interface Item {
  id: string
  title: string
  description: string
  price_per_day: number
  location: string
  image_url: string
  is_available: boolean
  created_at: string
  user: {
    id: string
    name: string
    email: string
  }
  category: {
    name: string
    icon: string
  }
}

interface BookingForm {
  start_date: string
  end_date: string
  message: string
}

export default function ItemDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()
  const [item, setItem] = useState<Item | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [bookingForm, setBookingForm] = useState<BookingForm>({
    start_date: '',
    end_date: '',
    message: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const [bookingSuccess, setBookingSuccess] = useState(false)

  // Lädt den Gegenstand beim Start
  useEffect(() => {
    if (params.id) {
      loadItem(params.id as string)
    }
  }, [params.id])

  // Lädt die Details eines Gegenstands
  const loadItem = async (itemId: string) => {
    try {
      setLoading(true)
      
      const { data, error } = await supabase
        .from('items')
        .select(`
          *,
          user:profiles(id, name, email),
          category:categories(name, icon)
        `)
        .eq('id', itemId)
        .single()

      if (error) throw error
      
      setItem(data)
    } catch (error) {
      console.error('Fehler beim Laden des Gegenstands:', error)
      setError('Gegenstand konnte nicht geladen werden')
    } finally {
      setLoading(false)
    }
  }

  // Behandelt Änderungen im Buchungsformular
  const handleBookingChange = (field: keyof BookingForm, value: string) => {
    setBookingForm(prev => ({
      ...prev,
      [field]: value
    }))
  }

  // Behandelt das Absenden der Buchungsanfrage
  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      // Validierung
      if (!bookingForm.start_date || !bookingForm.end_date) {
        throw new Error('Bitte wähle Start- und Enddatum aus')
      }

      const startDate = new Date(bookingForm.start_date)
      const endDate = new Date(bookingForm.end_date)
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      if (startDate < today) {
        throw new Error('Startdatum kann nicht in der Vergangenheit liegen')
      }

      if (endDate <= startDate) {
        throw new Error('Enddatum muss nach dem Startdatum liegen')
      }

      // Berechnet den Gesamtpreis
      const days = calculateDays(startDate, endDate)
      const totalPrice = days * item!.price_per_day

      // Erstellt die Buchungsanfrage
      const { error: insertError } = await supabase
        .from('rentals')
        .insert({
          item_id: item!.id,
          renter_id: user!.id,
          owner_id: item!.user.id,
          start_date: bookingForm.start_date,
          end_date: bookingForm.end_date,
          status: 'pending',
          total_price: totalPrice
        })

      if (insertError) throw insertError

      setBookingSuccess(true)
      
      // Nach 3 Sekunden das Formular ausblenden
      setTimeout(() => {
        setShowBookingForm(false)
        setBookingSuccess(false)
        setBookingForm({ start_date: '', end_date: '', message: '' })
      }, 3000)

    } catch (error: any) {
      setError(error.message || 'Ein Fehler ist aufgetreten')
    } finally {
      setSubmitting(false)
    }
  }

  // Zeigt Ladebildschirm
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  // Zeigt Fehlermeldung
  if (error || !item) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Fehler beim Laden
          </h2>
          <p className="text-gray-600 mb-6">
            {error || 'Der angeforderte Gegenstand wurde nicht gefunden'}
          </p>
          <Button onClick={() => router.push('/browse')}>
            <ArrowLeft className="w-5 h-5 mr-2" />
            Zurück zur Übersicht
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-6xl">
        {/* Zurück-Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6"
        >
          <Button
            variant="ghost"
            onClick={() => router.push('/browse')}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Zurück zur Übersicht</span>
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Linke Spalte - Hauptinhalt */}
          <div className="lg:col-span-2 space-y-6">
            {/* Bild */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="relative h-96 bg-gray-200 rounded-2xl overflow-hidden">
                {item.image_url ? (
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    <div className="text-8xl">{item.category?.icon || '📦'}</div>
                  </div>
                )}
                
                {/* Verfügbarkeits-Badge */}
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-2 rounded-full text-sm font-medium ${
                    item.is_available 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {item.is_available ? 'Verfügbar' : 'Nicht verfügbar'}
                  </span>
                </div>

                {/* Aktions-Buttons */}
                <div className="absolute top-4 left-4 flex space-x-2">
                  <Button variant="ghost" size="icon" className="bg-white/90 hover:bg-white">
                    <Heart className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="bg-white/90 hover:bg-white">
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </motion.div>

            {/* Titel und Kategorie */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
                    {item.title}
                  </h1>
                  <div className="flex items-center space-x-4">
                    <span className="inline-flex items-center px-3 py-1 bg-primary-100 text-primary-800 text-sm font-medium rounded-lg">
                      {item.category?.icon} {item.category?.name}
                    </span>
                    <span className="text-gray-500">
                      Eingestellt am {formatDate(item.created_at)}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Beschreibung */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle>Beschreibung</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed">
                    {item.description || 'Keine Beschreibung verfügbar.'}
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Verleiher-Informationen */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle>Über den Verleiher</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
                      <User className="w-8 h-8 text-primary-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 text-lg">
                        {item.user.name}
                      </h3>
                      <p className="text-gray-600">
                        Mitglied seit {formatDate(item.user.id)} {/* Vereinfacht - normalerweise würde man das Registrierungsdatum speichern */}
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button variant="outline" className="w-full">
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Nachricht senden
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Phone className="w-5 h-5 mr-2" />
                      Anrufen
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Rechte Spalte - Buchung und Details */}
          <div className="space-y-6">
            {/* Preis und Buchung */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="card-hover sticky top-24">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-primary-600 mb-2">
                      {formatPrice(item.price_per_day)}
                    </div>
                    <p className="text-gray-600">pro Tag</p>
                  </div>

                  {item.is_available ? (
                    user ? (
                      user.id === item.user.id ? (
                        <div className="text-center py-4">
                          <p className="text-gray-600 mb-4">
                            Das ist dein eigener Gegenstand
                          </p>
                          <Button
                            variant="outline"
                            onClick={() => router.push('/dashboard')}
                            className="w-full"
                          >
                            Zum Dashboard
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <Button
                            onClick={() => setShowBookingForm(!showBookingForm)}
                            className="w-full"
                            size="lg"
                          >
                            <Calendar className="w-5 h-5 mr-2" />
                            Jetzt buchen
                          </Button>
                          
                          <Button variant="outline" className="w-full">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Nachricht senden
                          </Button>
                        </div>
                      )
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-gray-600 mb-4">
                          Melde dich an, um zu buchen
                        </p>
                        <Button
                          onClick={() => router.push('/auth/signin')}
                          className="w-full"
                        >
                          Anmelden
                        </Button>
                      </div>
                    )}
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-gray-600 mb-4">
                        Dieser Gegenstand ist derzeit nicht verfügbar
                      </p>
                      <Button variant="outline" className="w-full">
                        <MessageCircle className="w-5 h-5 mr-2" />
                        Nachricht senden
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Standort */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="w-5 h-5 mr-2" />
                    Standort
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">{item.location}</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Bewertungen (Platzhalter) */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="w-5 h-5 mr-2" />
                    Bewertungen
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4">
                    <div className="text-2xl mb-2">⭐</div>
                    <p className="text-gray-600">
                      Noch keine Bewertungen
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Buchungsformular */}
        {showBookingForm && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mt-12"
          >
            <Card className="card-hover">
              <CardHeader>
                <CardTitle>Buchungsanfrage</CardTitle>
              </CardHeader>
              <CardContent>
                {bookingSuccess ? (
                  <div className="text-center py-8">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-green-900 mb-2">
                      Buchungsanfrage gesendet!
                    </h3>
                    <p className="text-green-700">
                      Der Verleiher wird sich bald bei dir melden.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleBookingSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="start_date" className="block text-sm font-medium text-gray-700 mb-2">
                          Startdatum *
                        </label>
                        <input
                          id="start_date"
                          type="date"
                          value={bookingForm.start_date}
                          onChange={(e) => handleBookingChange('start_date', e.target.value)}
                          required
                          min={new Date().toISOString().split('T')[0]}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="end_date" className="block text-sm font-medium text-gray-700 mb-2">
                          Enddatum *
                        </label>
                        <input
                          id="end_date"
                          type="date"
                          value={bookingForm.end_date}
                          onChange={(e) => handleBookingChange('end_date', e.target.value)}
                          required
                          min={bookingForm.start_date || new Date().toISOString().split('T')[0]}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                        Nachricht an den Verleiher (optional)
                      </label>
                      <textarea
                        id="message"
                        value={bookingForm.message}
                        onChange={(e) => handleBookingChange('message', e.target.value)}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
                        placeholder="Teile dem Verleiher mit, wofür du den Gegenstand brauchst..."
                      />
                    </div>

                    {/* Fehlermeldung */}
                    {error && (
                      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700">
                        {error}
                      </div>
                    )}

                    {/* Preisberechnung */}
                    {bookingForm.start_date && bookingForm.end_date && (
                      <div className="bg-gray-50 rounded-xl p-4">
                        <div className="flex justify-between items-center text-lg font-medium">
                          <span>Gesamtpreis:</span>
                          <span className="text-primary-600">
                            {formatPrice(calculateDays(bookingForm.start_date, bookingForm.end_date) * item.price_per_day)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          {calculateDays(bookingForm.start_date, bookingForm.end_date)} Tage × {formatPrice(item.price_per_day)}/Tag
                        </p>
                      </div>
                    )}

                    <div className="flex space-x-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowBookingForm(false)}
                        className="flex-1"
                      >
                        Abbrechen
                      </Button>
                      <Button
                        type="submit"
                        disabled={submitting || !bookingForm.start_date || !bookingForm.end_date}
                        className="flex-1"
                      >
                        {submitting ? 'Wird gesendet...' : 'Buchungsanfrage senden'}
                      </Button>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}

