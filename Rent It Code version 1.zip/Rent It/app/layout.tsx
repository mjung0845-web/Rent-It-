import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Header from '../components/Header'
import Footer from '../components/Footer'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'RentIt - Dein Marktplatz für Produktvermietung',
  description: 'Entdecke und vermiete Produkte aller Art. Von Camping-Ausrüstung bis Werkzeug - alles was du brauchst!',
  keywords: 'vermietung, marktplatz, camping, party, werkzeug, sport, elektronik',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="de">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  )
}
