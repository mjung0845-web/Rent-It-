import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'
import { Home, Search, Package, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-2xl mx-auto"
      >
        {/* 404 Icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-8xl mb-6"
        >
          🚫
        </motion.div>

        {/* Titel */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-4xl md:text-6xl font-bold text-gray-900 mb-4"
        >
          Seite nicht gefunden
        </motion.h1>

        {/* Beschreibung */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-xl text-gray-600 mb-8"
        >
          Die Seite, die du suchst, existiert nicht oder wurde verschoben.
        </motion.p>

        {/* Aktions-Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8"
        >
          <Link href="/">
            <Button size="lg" className="w-full sm:w-auto">
              <Home className="w-5 h-5 mr-2" />
              Zur Startseite
            </Button>
          </Link>
          
          <Link href="/browse">
            <Button variant="outline" size="lg" className="w-full sm:w-auto">
              <Search className="w-5 h-5 mr-2" />
              Gegenstände durchsuchen
            </Button>
          </Link>
        </motion.div>

        {/* Weitere Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
        >
          <Link 
            href="/list"
            className="p-4 bg-white rounded-2xl shadow-soft hover:shadow-soft-lg transition-all hover:-translate-y-1"
          >
            <Package className="w-8 h-8 text-primary-500 mx-auto mb-2" />
            <h3 className="font-semibold text-gray-900 mb-1">Gegenstand einstellen</h3>
            <p className="text-sm text-gray-600">Verdiene Geld mit deinen Sachen</p>
          </Link>
          
          <Link 
            href="/auth/signup"
            className="p-4 bg-white rounded-2xl shadow-soft hover:shadow-soft-lg transition-all hover:-translate-y-1"
          >
            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-primary-600 font-bold">+</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Registrieren</h3>
            <p className="text-sm text-gray-600">Werde Teil der Community</p>
          </Link>
          
          <Link 
            href="/auth/signin"
            className="p-4 bg-white rounded-2xl shadow-soft hover:shadow-soft-lg transition-all hover:-translate-y-1"
          >
            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-primary-600 font-bold">→</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Anmelden</h3>
            <p className="text-sm text-gray-600">Zugang zu deinem Konto</p>
          </Link>
        </motion.div>

        {/* Zurück-Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.7 }}
        >
          <Button
            variant="ghost"
            onClick={() => window.history.back()}
            className="flex items-center space-x-2 mx-auto"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Zurück</span>
          </Button>
        </motion.div>
      </motion.div>
    </div>
  )
}

