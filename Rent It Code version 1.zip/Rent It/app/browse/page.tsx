'use client'

import { useState, useEffect } from 'react'
import { Search, Filter, MapPin, Star, Calendar, User } from 'lucide-react'
import { productService } from '../../services/api'
import { Product, ProductFilters, PRODUCT_CATEGORIES, QUALITY_LEVELS } from '../../types/product'
import ProductCard from '../../components/ProductCard'

export default function BrowsePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filters, setFilters] = useState<ProductFilters>({})
  const [sortBy, setSortBy] = useState('newest')

  useEffect(() => {
    loadProducts()
  }, [])

  useEffect(() => {
    applyFiltersAndSearch()
  }, [products, searchTerm, filters, sortBy])

  const loadProducts = async () => {
    try {
      setLoading(true)
      const allProducts = await productService.getAllProducts()
      setProducts(allProducts)
    } catch (error) {
      console.error('Fehler beim Laden der Produkte:', error)
    } finally {
      setLoading(false)
    }
  }

  const applyFiltersAndSearch = () => {
    let filtered = [...products]

    // Text-Suche
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchLower) ||
        product.description?.toLowerCase().includes(searchLower) ||
        product.category.toLowerCase().includes(searchLower)
      )
    }

    // Kategorie-Filter
    if (filters.category) {
      filtered = filtered.filter(product => product.category === filters.category)
    }

    // Preis-Filter
    if (filters.maxPrice) {
      filtered = filtered.filter(product => product.pricePerDay <= filters.maxPrice)
    }

    // Qualitäts-Filter
    if (filters.quality) {
      filtered = filtered.filter(product => product.quality === filters.quality)
    }

    // Verfügbarkeits-Filter
    if (filters.available !== undefined) {
      filtered = filtered.filter(product => product.available === filters.available)
    }

    // Sortierung
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.pricePerDay - b.pricePerDay)
        break
      case 'price-high':
        filtered.sort((a, b) => b.pricePerDay - a.pricePerDay)
        break
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        break
      case 'oldest':
        filtered.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
        break
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name))
        break
    }

    setFilteredProducts(filtered)
  }

  const clearFilters = () => {
    setSearchTerm('')
    setFilters({})
    setSortBy('newest')
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Produkte durchsuchen
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Finde genau das, was du brauchst, oder entdecke neue Möglichkeiten in deiner Nähe
          </p>
        </div>

        {/* Such- und Filter-Bereich */}
        <div className="bg-white rounded-2xl shadow-soft p-6 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* Suchfeld */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Was suchst du?"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-10"
              />
            </div>

            {/* Kategorie-Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={filters.category || ''}
                onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value || undefined }))}
                className="select-field pl-10"
              >
                <option value="">Alle Kategorien</option>
                {PRODUCT_CATEGORIES.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            {/* Qualitäts-Filter */}
            <div className="relative">
              <Star className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={filters.quality || ''}
                onChange={(e) => setFilters(prev => ({ ...prev, quality: e.target.value || undefined }))}
                className="select-field pl-10"
              >
                <option value="">Alle Qualitäten</option>
                {QUALITY_LEVELS.map((quality) => (
                  <option key={quality.value} value={quality.value}>
                    {quality.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Sortierung */}
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="select-field pl-10"
              >
                <option value="newest">Neueste zuerst</option>
                <option value="oldest">Älteste zuerst</option>
                <option value="price-low">Preis: Niedrig zu Hoch</option>
                <option value="price-high">Preis: Hoch zu Niedrig</option>
                <option value="name">Name A-Z</option>
              </select>
            </div>
          </div>

          {/* Zusätzliche Filter */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            {/* Preis-Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Max. Preis pro Tag
              </label>
              <input
                type="number"
                placeholder="€"
                value={filters.maxPrice || ''}
                onChange={(e) => setFilters(prev => ({ 
                  ...prev, 
                  maxPrice: e.target.value ? parseFloat(e.target.value) : undefined 
                }))}
                className="input-field"
              />
            </div>

            {/* Verfügbarkeits-Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Verfügbarkeit
              </label>
              <select
                value={filters.available === undefined ? '' : filters.available.toString()}
                onChange={(e) => setFilters(prev => ({ 
                  ...prev, 
                  available: e.target.value === '' ? undefined : e.target.value === 'true' 
                }))}
                className="select-field"
              >
                <option value="">Alle</option>
                <option value="true">Nur verfügbare</option>
                <option value="false">Nur nicht verfügbare</option>
              </select>
            </div>

            {/* Filter zurücksetzen */}
            <div className="flex items-end">
              <button
                onClick={clearFilters}
                className="btn-secondary w-full"
              >
                Filter zurücksetzen
              </button>
            </div>
          </div>
        </div>

        {/* Ergebnisse */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Lade Produkte...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Keine Produkte gefunden
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || Object.keys(filters).length > 0
                ? 'Versuche andere Suchbegriffe oder Filter'
                : 'Es sind noch keine Produkte verfügbar'
              }
            </p>
            {(searchTerm || Object.keys(filters).length > 0) ? (
              <button onClick={clearFilters} className="btn-primary">
                Alle Filter zurücksetzen
              </button>
            ) : (
              <a href="/create" className="btn-primary">
                Erstes Produkt erstellen
              </a>
            )}
          </div>
        ) : (
          <>
            {/* Ergebnis-Zähler */}
            <div className="mb-6">
              <p className="text-gray-600">
                {filteredProducts.length} {filteredProducts.length === 1 ? 'Produkt' : 'Produkte'} gefunden
              </p>
            </div>

            {/* Produkte-Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
