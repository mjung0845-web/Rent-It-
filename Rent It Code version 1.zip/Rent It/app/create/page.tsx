'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Upload, Plus, ArrowLeft } from 'lucide-react'
import { productService } from '../../services/api'
import { CreateProductForm, PRODUCT_CATEGORIES, QUALITY_LEVELS } from '../../types/product'

export default function CreateProductPage() {
  const router = useRouter()
  const [formData, setFormData] = useState<CreateProductForm>({
    name: '',
    category: '',
    pricePerDay: '',
    quality: 'gut',
    deposit: '',
    description: ''
  })
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string>('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleInputChange = (field: keyof CreateProductForm, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    setError('')
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    try {
      // Validierung
      if (!formData.name.trim()) throw new Error('Produktname ist erforderlich')
      if (!formData.category) throw new Error('Kategorie ist erforderlich')
      if (!formData.pricePerDay || parseFloat(formData.pricePerDay) <= 0) {
        throw new Error('Gültiger Preis ist erforderlich')
      }
      if (!formData.deposit || parseFloat(formData.deposit) <= 0) {
        throw new Error('Gültige Kaution ist erforderlich')
      }
      if (!formData.description.trim()) throw new Error('Beschreibung ist erforderlich')

      // Produkt erstellen
      const newProduct = await productService.createProduct(formData)
      
      setSuccess(true)
      
      // Nach 3 Sekunden zur Startseite weiterleiten
      setTimeout(() => {
        router.push('/')
      }, 3000)

    } catch (error: any) {
      setError(error.message || 'Ein Fehler ist aufgetreten')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Produkt erstellen
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Stelle dein Produkt zur Vermietung ein und verdiene Geld damit
          </p>
        </div>

        {/* Erfolgsmeldung */}
        {success && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-6 mb-8 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-xl font-semibold text-green-900 mb-2">
              Produkt erfolgreich erstellt!
            </h3>
            <p className="text-green-700 mb-4">
              Dein Produkt ist jetzt für andere Nutzer sichtbar.
            </p>
            <p className="text-sm text-green-600">
              Du wirst in wenigen Sekunden zur Startseite weitergeleitet...
            </p>
          </div>
        )}

        {/* Hauptformular */}
        {!success && (
          <div className="card p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Produktname */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Name des Produkts *
                </label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                  className="input-field"
                  placeholder="z.B. Akku-Bohrmaschine Bosch Professional"
                />
              </div>

              {/* Kategorie und Qualität */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                    Kategorie *
                  </label>
                  <select
                    id="category"
                    value={formData.category}
                    onChange={(e) => handleInputChange('category', e.target.value)}
                    required
                    className="select-field"
                  >
                    <option value="">Kategorie wählen</option>
                    {PRODUCT_CATEGORIES.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="quality" className="block text-sm font-medium text-gray-700 mb-2">
                    Qualität *
                  </label>
                  <select
                    id="quality"
                    value={formData.quality}
                    onChange={(e) => handleInputChange('quality', e.target.value as any)}
                    required
                    className="select-field"
                  >
                    {QUALITY_LEVELS.map((quality) => (
                      <option key={quality.value} value={quality.value}>
                        {quality.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Preis und Kaution */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="pricePerDay" className="block text-sm font-medium text-gray-700 mb-2">
                    Preis pro Tag (€) *
                  </label>
                  <input
                    id="pricePerDay"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.pricePerDay}
                    onChange={(e) => handleInputChange('pricePerDay', e.target.value)}
                    required
                    className="input-field"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label htmlFor="deposit" className="block text-sm font-medium text-gray-700 mb-2">
                    Kaution (€) *
                  </label>
                  <input
                    id="deposit"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.deposit}
                    onChange={(e) => handleInputChange('deposit', e.target.value)}
                    required
                    className="input-field"
                    placeholder="0.00"
                  />
                </div>
              </div>

              {/* Produktbild */}
              <div>
                <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-2">
                  Produktbild
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-xl hover:border-primary-400 transition-colors">
                  <div className="space-y-1 text-center">
                    {imagePreview ? (
                      <div className="mb-4">
                        <img
                          src={imagePreview}
                          alt="Vorschau"
                          className="mx-auto h-32 w-auto rounded-lg object-cover"
                        />
                      </div>
                    ) : (
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    )}
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="image"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500"
                      >
                        <span>Bild hochladen</span>
                        <input
                          id="image"
                          name="image"
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                      <p className="pl-1">oder per Drag & Drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PNG, JPG, GIF bis 10MB
                    </p>
                  </div>
                </div>
              </div>

              {/* Beschreibung */}
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                  Beschreibung *
                </label>
                <textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  required
                  rows={4}
                  className="input-field resize-none"
                  placeholder="Beschreibe dein Produkt detailliert. Was macht es besonders? Welchen Zustand hat es? Welche Funktionen bietet es?"
                />
              </div>

              {/* Fehlermeldung */}
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700">
                  {error}
                </div>
              )}

              {/* Submit-Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <button
                  type="button"
                  onClick={() => router.push('/')}
                  className="btn-secondary flex-1 flex items-center justify-center"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Zurück zur Startseite
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary flex-1 flex items-center justify-center"
                >
                  {submitting ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Wird erstellt...
                    </>
                  ) : (
                    <>
                      <Plus className="w-5 h-5 mr-2" />
                      Produkt erstellen
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Hilfetext */}
        <div className="mt-8 text-center text-gray-600">
          <p className="text-sm">
            * Pflichtfelder. Alle Produkte werden von uns überprüft, bevor sie veröffentlicht werden.
          </p>
        </div>
      </div>
    </div>
  )
}
