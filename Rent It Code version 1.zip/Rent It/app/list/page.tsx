'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/AuthProvider'
import { motion } from 'framer-motion'
import { Upload, X, Plus, MapPin, Tag, Euro, FileText, Image as ImageIcon } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase'

// Typen für die Kategorien
interface Category {
  id: string
  name: string
  icon: string
}

// Typen für das Formular
interface ItemForm {
  title: string
  description: string
  category_id: string
  price_per_day: string
  location: string
  images: File[]
}

export default function ListItemPage() {
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()
  const [categories, setCategories] = useState<Category[]>([])
  const [formData, setFormData] = useState<ItemForm>({
    title: '',
    description: '',
    category_id: '',
    price_per_day: '',
    location: '',
    images: []
  })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  // Lädt Kategorien beim Start
  useEffect(() => {
    loadCategories()
  }, [])

  // Überprüft, ob der Benutzer angemeldet ist
  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin?redirect=/list')
    }
  }, [user, authLoading, router])

  // Lädt alle verfügbaren Kategorien
  const loadCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name')

      if (error) throw error
      setCategories(data || [])
    } catch (error) {
      console.error('Fehler beim Laden der Kategorien:', error)
    }
  }

  // Behandelt Änderungen in den Formularfeldern
  const handleInputChange = (field: keyof ItemForm, value: string | File[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    setError('') // Löscht Fehlermeldungen bei Eingabe
  }

  // Behandelt das Hinzufügen von Bildern
  const handleImageAdd = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    const validFiles = files.filter(file => 
      file.type.startsWith('image/') && file.size <= 5 * 1024 * 1024 // Max 5MB
    )

    if (validFiles.length + formData.images.length > 5) {
      setError('Maximal 5 Bilder erlaubt')
      return
    }

    setFormData(prev => ({
      ...prev,
      images: [...prev.images, ...validFiles]
    }))
    setError('')
  }

  // Entfernt ein Bild aus der Liste
  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }))
  }

  // Lädt ein Bild zu Supabase Storage hoch
  const uploadImage = async (file: File): Promise<string> => {
    const fileExt = file.name.split('.').pop()
    const fileName = `${Math.random()}.${fileExt}`
    const filePath = `item-images/${fileName}`

    const { error: uploadError } = await supabase.storage
      .from('item-images')
      .upload(filePath, file)

    if (uploadError) throw uploadError

    const { data: { publicUrl } } = supabase.storage
      .from('item-images')
      .getPublicUrl(filePath)

    return publicUrl
  }

  // Behandelt das Absenden des Formulars
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    try {
      // Validierung
      if (!formData.title.trim()) throw new Error('Titel ist erforderlich')
      if (!formData.description.trim()) throw new Error('Beschreibung ist erforderlich')
      if (!formData.category_id) throw new Error('Kategorie ist erforderlich')
      if (!formData.price_per_day || parseFloat(formData.price_per_day) <= 0) {
        throw new Error('Gültiger Preis ist erforderlich')
      }
      if (!formData.location.trim()) throw new Error('Standort ist erforderlich')

      // Bilder hochladen
      const imageUrls: string[] = []
      for (const image of formData.images) {
        const imageUrl = await uploadImage(image)
        imageUrls.push(imageUrl)
      }

      // Gegenstand in der Datenbank erstellen
      const { error: insertError } = await supabase
        .from('items')
        .insert({
          title: formData.title.trim(),
          description: formData.description.trim(),
          category_id: formData.category_id,
          price_per_day: parseFloat(formData.price_per_day),
          location: formData.location.trim(),
          image_url: imageUrls[0] || null, // Erstes Bild als Hauptbild
          user_id: user!.id,
          is_available: true
        })

      if (insertError) throw insertError

      setSuccess(true)
      
      // Nach 3 Sekunden zum Dashboard weiterleiten
      setTimeout(() => {
        router.push('/dashboard')
      }, 3000)

    } catch (error: any) {
      setError(error.message || 'Ein Fehler ist aufgetreten')
    } finally {
      setSubmitting(false)
    }
  }

  // Zeigt Ladebildschirm während der Authentifizierung
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  // Zeigt Weiterleitung, wenn nicht angemeldet
  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Gegenstand einstellen
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Teile deine Gegenstände mit der Community und verdiene Geld damit
          </p>
        </motion.div>

        {/* Erfolgsmeldung */}
        {success && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-green-50 border border-green-200 rounded-2xl p-6 mb-8 text-center"
          >
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-xl font-semibold text-green-900 mb-2">
              Gegenstand erfolgreich eingestellt!
            </h3>
            <p className="text-green-700 mb-4">
              Dein Gegenstand ist jetzt für andere Nutzer sichtbar.
            </p>
            <p className="text-sm text-green-600">
              Du wirst in wenigen Sekunden zum Dashboard weitergeleitet...
            </p>
          </motion.div>
        )}

        {/* Hauptformular */}
        {!success && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <Card className="card-hover">
              <CardHeader>
                <CardTitle className="text-2xl">Gegenstandsdetails</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Titel */}
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                      Titel des Gegenstands *
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        id="title"
                        type="text"
                        value={formData.title}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        required
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="z.B. Akku-Bohrmaschine Bosch Professional"
                      />
                    </div>
                  </div>

                  {/* Beschreibung */}
                  <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                      Beschreibung *
                    </label>
                    <textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      required
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
                      placeholder="Beschreibe deinen Gegenstand detailliert. Was macht ihn besonders? Welchen Zustand hat er?"
                    />
                  </div>

                  {/* Kategorie und Preis */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                        Kategorie *
                      </label>
                      <div className="relative">
                        <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <select
                          id="category"
                          value={formData.category_id}
                          onChange={(e) => handleInputChange('category_id', e.target.value)}
                          required
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all appearance-none bg-white"
                        >
                          <option value="">Kategorie wählen</option>
                          {categories.map((category) => (
                            <option key={category.id} value={category.id}>
                              {category.icon} {category.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                        Preis pro Tag (€) *
                      </label>
                      <div className="relative">
                        <Euro className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                          id="price"
                          type="number"
                          step="0.01"
                          min="0.01"
                          value={formData.price_per_day}
                          onChange={(e) => handleInputChange('price_per_day', e.target.value)}
                          required
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Standort */}
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                      Standort *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        id="location"
                        type="text"
                        value={formData.location}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                        required
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="z.B. Berlin, Mitte"
                      />
                    </div>
                  </div>

                  {/* Bild-Upload */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Bilder (optional, max. 5)
                    </label>
                    <div className="space-y-4">
                      {/* Bild-Upload-Button */}
                      <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-primary-300 transition-colors">
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleImageAdd}
                          className="hidden"
                          id="image-upload"
                        />
                        <label htmlFor="image-upload" className="cursor-pointer">
                          <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-600">
                            Klicke hier, um Bilder hochzuladen
                          </p>
                          <p className="text-sm text-gray-500 mt-1">
                            JPG, PNG bis 5MB
                          </p>
                        </label>
                      </div>

                      {/* Vorschau der hochgeladenen Bilder */}
                      {formData.images.length > 0 && (
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          {formData.images.map((image, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={URL.createObjectURL(image)}
                                alt={`Vorschau ${index + 1}`}
                                className="w-full h-32 object-cover rounded-lg"
                              />
                              <button
                                type="button"
                                onClick={() => removeImage(index)}
                                className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Fehlermeldung */}
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700"
                    >
                      {error}
                    </motion.div>
                  )}

                  {/* Submit-Button */}
                  <div className="flex justify-end space-x-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => router.push('/dashboard')}
                    >
                      Abbrechen
                    </Button>
                    <Button
                      type="submit"
                      disabled={submitting}
                      className="min-w-[120px]"
                    >
                      {submitting ? 'Wird eingestellt...' : 'Gegenstand einstellen'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}
