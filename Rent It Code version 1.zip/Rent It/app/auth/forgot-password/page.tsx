'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useAuth } from '@/components/AuthProvider'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { motion } from 'framer-motion'
import { Mail, ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react'

export default function ForgotPasswordPage() {
  const { resetPassword } = useAuth()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  // Behandelt das Absenden der Passwort-Zurücksetzung
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      await resetPassword(email)
      setSuccess(true)
    } catch (error: any) {
      setError(error.message || 'Ein Fehler ist aufgetreten')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full"
      >
        {/* Logo und Titel */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <div className="w-12 h-12 bg-primary-500 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-2xl">R</span>
            </div>
            <span className="text-3xl font-bold text-primary-500">RentIt</span>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Passwort vergessen?</h1>
          <p className="text-gray-600 mt-2">
            Gib deine E-Mail-Adresse ein und wir senden dir einen Link zum Zurücksetzen deines Passworts.
          </p>
        </div>

        {/* Passwort-Zurücksetzungsformular */}
        <Card className="card-hover">
          <CardHeader>
            <CardTitle className="text-xl text-center">Passwort zurücksetzen</CardTitle>
          </CardHeader>
          <CardContent>
            {success ? (
              /* Erfolgsmeldung */
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-8"
              >
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  E-Mail gesendet!
                </h3>
                <p className="text-gray-600 mb-4">
                  Wir haben dir eine E-Mail mit einem Link zum Zurücksetzen deines Passworts gesendet.
                </p>
                <p className="text-sm text-gray-500">
                  Überprüfe deinen Posteingang und folge den Anweisungen.
                </p>
              </motion.div>
            ) : (
              /* Formular */
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* E-Mail-Feld */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    E-Mail-Adresse
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                      placeholder="ihre@email.de"
                    />
                  </div>
                </div>

                {/* Fehlermeldung */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="flex items-center p-3 bg-red-50 border border-red-200 rounded-xl text-red-700"
                  >
                    <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
                    <span className="text-sm">{error}</span>
                  </motion.div>
                )}

                {/* Submit-Button */}
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 text-lg"
                >
                  {loading ? 'Wird gesendet...' : 'Link senden'}
                </Button>
              </form>
            )}

            {/* Zurück zur Anmeldung */}
            <div className="mt-6 text-center">
              <Link
                href="/auth/signin"
                className="inline-flex items-center text-primary-600 hover:text-primary-500 font-medium transition-colors"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Zurück zur Anmeldung
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}

