'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/AuthProvider'
import { motion } from 'framer-motion'
import { 
  Package, 
  Calendar, 
  TrendingUp, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  MapPin,
  Euro,
  User,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase'
import { formatPrice, formatDate } from '@/lib/utils'

// Typen für die Daten
interface Item {
  id: string
  title: string
  description: string
  price_per_day: number
  location: string
  image_url: string
  is_available: boolean
  created_at: string
  category: {
    name: string
    icon: string
  }
}

interface Rental {
  id: string
  start_date: string
  end_date: string
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed'
  total_price: number
  item: {
    title: string
    image_url: string
    owner: {
      name: string
    }
  }
  owner: {
    name: string
  }
}

interface Stats {
  totalItems: number
  activeItems: number
  totalRentals: number
  totalEarnings: number
}

export default function DashboardPage() {
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [items, setItems] = useState<Item[]>([])
  const [rentals, setRentals] = useState<Rental[]>([])
  const [stats, setStats] = useState<Stats>({
    totalItems: 0,
    activeItems: 0,
    totalRentals: 0,
    totalEarnings: 0
  })
  const [loading, setLoading] = useState(true)

  // Lädt Daten beim Start
  useEffect(() => {
    if (user) {
      loadDashboardData()
    }
  }, [user])

  // Überprüft, ob der Benutzer angemeldet ist
  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin')
    }
  }, [user, authLoading, router])

  // Lädt alle Dashboard-Daten
  const loadDashboardData = async () => {
    try {
      setLoading(true)
      await Promise.all([
        loadItems(),
        loadRentals(),
        loadStats()
      ])
    } catch (error) {
      console.error('Fehler beim Laden der Dashboard-Daten:', error)
    } finally {
      setLoading(false)
    }
  }

  // Lädt die eigenen Gegenstände
  const loadItems = async () => {
    try {
      const { data, error } = await supabase
        .from('items')
        .select(`
          *,
          category:categories(name, icon)
        `)
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setItems(data || [])
    } catch (error) {
      console.error('Fehler beim Laden der Gegenstände:', error)
    }
  }

  // Lädt alle Buchungen (als Mieter und Verleiher)
  const loadRentals = async () => {
    try {
      const { data, error } = await supabase
        .from('rentals')
        .select(`
          *,
          item:items(
            title,
            image_url,
            owner:profiles(name)
          ),
          owner:profiles(name)
        `)
        .or(`renter_id.eq.${user!.id},owner_id.eq.${user!.id}`)
        .order('created_at', { ascending: false })

      if (error) throw error
      setRentals(data || [])
    } catch (error) {
      console.error('Fehler beim Laden der Buchungen:', error)
    }
  }

  // Lädt Statistiken
  const loadStats = async () => {
    try {
      const totalItems = items.length
      const activeItems = items.filter(item => item.is_available).length
      const totalRentals = rentals.length
      const totalEarnings = rentals
        .filter(rental => rental.status === 'completed' && rental.owner?.name === user?.user_metadata?.name)
        .reduce((sum, rental) => sum + (rental.total_price || 0), 0)

      setStats({
        totalItems,
        activeItems,
        totalRentals,
        totalEarnings
      })
    } catch (error) {
      console.error('Fehler beim Laden der Statistiken:', error)
    }
  }

  // Löscht einen Gegenstand
  const deleteItem = async (itemId: string) => {
    if (!confirm('Möchtest du diesen Gegenstand wirklich löschen?')) return

    try {
      const { error } = await supabase
        .from('items')
        .delete()
        .eq('id', itemId)

      if (error) throw error

      // Aktualisiert die lokale Liste
      setItems(prev => prev.filter(item => item.id !== itemId))
      loadStats() // Aktualisiert Statistiken
    } catch (error) {
      console.error('Fehler beim Löschen des Gegenstands:', error)
    }
  }

  // Ändert den Verfügbarkeitsstatus
  const toggleAvailability = async (itemId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('items')
        .update({ is_available: !currentStatus })
        .eq('id', itemId)

      if (error) throw error

      // Aktualisiert die lokale Liste
      setItems(prev => prev.map(item => 
        item.id === itemId 
          ? { ...item, is_available: !currentStatus }
          : item
      ))
      loadStats() // Aktualisiert Statistiken
    } catch (error) {
      console.error('Fehler beim Ändern des Status:', error)
    }
  }

  // Zeigt den Status einer Buchung an
  const getRentalStatus = (status: string) => {
    switch (status) {
      case 'pending':
        return { icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-100', text: 'Ausstehend' }
      case 'confirmed':
        return { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-100', text: 'Bestätigt' }
      case 'cancelled':
        return { icon: XCircle, color: 'text-red-600', bg: 'bg-red-100', text: 'Storniert' }
      case 'completed':
        return { icon: CheckCircle, color: 'text-blue-600', bg: 'bg-blue-100', text: 'Abgeschlossen' }
      default:
        return { icon: AlertCircle, color: 'text-gray-600', bg: 'bg-gray-100', text: 'Unbekannt' }
    }
  }

  // Zeigt Ladebildschirm während der Authentifizierung
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  // Zeigt Weiterleitung, wenn nicht angemeldet
  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Dashboard
          </h1>
          <p className="text-xl text-gray-600">
            Willkommen zurück, {user.user_metadata?.name || 'Benutzer'}!
          </p>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="bg-white rounded-2xl shadow-soft p-2 mb-8"
        >
          <div className="flex space-x-2">
            {[
              { id: 'overview', label: 'Übersicht', icon: TrendingUp },
              { id: 'items', label: 'Meine Gegenstände', icon: Package },
              { id: 'rentals', label: 'Buchungen', icon: Calendar }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-3 rounded-xl font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-primary-500 text-white shadow-soft'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Tab-Inhalte */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Lade Dashboard...</p>
          </div>
        ) : (
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Übersicht */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Statistiken */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card className="card-hover">
                    <CardContent className="p-6 text-center">
                      <Package className="w-8 h-8 text-primary-500 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-gray-900 mb-1">{stats.totalItems}</div>
                      <p className="text-gray-600">Gegenstände</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="card-hover">
                    <CardContent className="p-6 text-center">
                      <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-gray-900 mb-1">{stats.activeItems}</div>
                      <p className="text-gray-600">Verfügbar</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="card-hover">
                    <CardContent className="p-6 text-center">
                      <Calendar className="w-8 h-8 text-blue-500 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-gray-900 mb-1">{stats.totalRentals}</div>
                      <p className="text-gray-600">Buchungen</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="card-hover">
                    <CardContent className="p-6 text-center">
                      <Euro className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-gray-900 mb-1">{formatPrice(stats.totalEarnings)}</div>
                      <p className="text-gray-600">Verdient</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Schnellaktionen */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle>Schnellaktionen</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-4">
                      <Button onClick={() => router.push('/list')}>
                        <Plus className="w-5 h-5 mr-2" />
                        Neuen Gegenstand einstellen
                      </Button>
                      <Button variant="outline" onClick={() => setActiveTab('items')}>
                        <Package className="w-5 h-5 mr-2" />
                        Gegenstände verwalten
                      </Button>
                      <Button variant="outline" onClick={() => setActiveTab('rentals')}>
                        <Calendar className="w-5 h-5 mr-2" />
                        Buchungen anzeigen
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Neueste Aktivitäten */}
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle>Neueste Aktivitäten</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {items.length === 0 && rentals.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">
                        Noch keine Aktivitäten. Starte damit, deinen ersten Gegenstand einzustellen!
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {items.slice(0, 3).map((item) => (
                          <div key={item.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-xl">
                            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                              <Package className="w-6 h-6 text-primary-600" />
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">{item.title}</p>
                              <p className="text-sm text-gray-500">Eingestellt am {formatDate(item.created_at)}</p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => router.push(`/item/${item.id}`)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Meine Gegenstände */}
            {activeTab === 'items' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Meine Gegenstände</h2>
                  <Button onClick={() => router.push('/list')}>
                    <Plus className="w-5 h-5 mr-2" />
                    Neuen Gegenstand einstellen
                  </Button>
                </div>

                {items.length === 0 ? (
                  <Card className="card-hover">
                    <CardContent className="p-12 text-center">
                      <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        Noch keine Gegenstände
                      </h3>
                      <p className="text-gray-600 mb-6">
                        Stelle deinen ersten Gegenstand ein und starte damit, Geld zu verdienen!
                      </p>
                      <Button onClick={() => router.push('/list')}>
                        <Plus className="w-5 h-5 mr-2" />
                        Ersten Gegenstand einstellen
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {items.map((item) => (
                      <Card key={item.id} className="card-hover">
                        <div className="relative h-48 bg-gray-200 overflow-hidden">
                          {item.image_url ? (
                            <img
                              src={item.image_url}
                              alt={item.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-400">
                              <div className="text-4xl">{item.category?.icon || '📦'}</div>
                            </div>
                          )}
                          <div className="absolute top-3 right-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              item.is_available 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {item.is_available ? 'Verfügbar' : 'Nicht verfügbar'}
                            </span>
                          </div>
                        </div>
                        
                        <CardContent className="p-4">
                          <div className="mb-3">
                            <span className="inline-block px-2 py-1 bg-primary-100 text-primary-800 text-xs font-medium rounded-lg">
                              {item.category?.name || 'Sonstiges'}
                            </span>
                          </div>
                          
                          <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                            {item.title}
                          </h3>
                          
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center text-sm text-gray-500">
                              <MapPin className="w-4 h-4 mr-1" />
                              {item.location}
                            </div>
                            <div className="text-lg font-bold text-primary-600">
                              {formatPrice(item.price_per_day)}/Tag
                            </div>
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => router.push(`/item/${item.id}`)}
                              className="flex-1"
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              Anzeigen
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => toggleAvailability(item.id, item.is_available)}
                              className="flex-1"
                            >
                              {item.is_available ? 'Deaktivieren' : 'Aktivieren'}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => deleteItem(item.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Buchungen */}
            {activeTab === 'rentals' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Meine Buchungen</h2>

                {rentals.length === 0 ? (
                  <Card className="card-hover">
                    <CardContent className="p-12 text-center">
                      <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        Noch keine Buchungen
                      </h3>
                      <p className="text-gray-600">
                        Du hast noch keine Gegenstände gemietet oder verliehen.
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {rentals.map((rental) => {
                      const statusInfo = getRentalStatus(rental.status)
                      const StatusIcon = statusInfo.icon
                      
                      return (
                        <Card key={rental.id} className="card-hover">
                          <CardContent className="p-6">
                            <div className="flex items-start space-x-4">
                              <div className="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                                {rental.item.image_url ? (
                                  <img
                                    src={rental.item.image_url}
                                    alt={rental.item.title}
                                    className="w-full h-full object-cover"
                                  />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                                    📦
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-start justify-between mb-2">
                                  <h3 className="font-semibold text-gray-900">
                                    {rental.item.title}
                                  </h3>
                                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusInfo.bg} ${statusInfo.color}`}>
                                    <StatusIcon className="w-4 h-4 inline mr-1" />
                                    {statusInfo.text}
                                  </span>
                                </div>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                                  <div>
                                    <span className="font-medium">Zeitraum:</span><br />
                                    {formatDate(rental.start_date)} - {formatDate(rental.end_date)}
                                  </div>
                                  <div>
                                    <span className="font-medium">Preis:</span><br />
                                    {formatPrice(rental.total_price || 0)}
                                  </div>
                                  <div>
                                    <span className="font-medium">Status:</span><br />
                                    {rental.owner?.name === user?.user_metadata?.name ? 'Verliehen an' : 'Gemietet von'} {' '}
                                    {rental.owner?.name === user?.user_metadata?.name 
                                      ? 'Mieter' 
                                      : rental.owner?.name || 'Unbekannt'
                                    }
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  )
}
