'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Star, Calendar, MapPin, Euro, Package, AlertCircle, CheckCircle } from 'lucide-react'
import { productService } from '../../../services/api'
import { Product, QUALITY_LEVELS } from '../../../types/product'

export default function ProductDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (params.id) {
      loadProduct(params.id as string)
    }
  }, [params.id])

  const loadProduct = async (id: string) => {
    try {
      setLoading(true)
      const productData = await productService.getProductById(id)
      
      if (!productData) {
        setError('Produkt nicht gefunden')
        return
      }
      
      setProduct(productData)
    } catch (error) {
      console.error('Fehler beim Laden des Produkts:', error)
      setError('Fehler beim Laden des Produkts')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container-custom max-w-6xl">
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Lade Produkt...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container-custom max-w-6xl">
          <div className="text-center py-12">
            <div className="text-6xl mb-4">❌</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {error || 'Produkt nicht gefunden'}
            </h3>
            <p className="text-gray-600 mb-6">
              Das gesuchte Produkt existiert nicht oder wurde entfernt.
            </p>
            <button
              onClick={() => router.push('/browse')}
              className="btn-primary"
            >
              Zurück zur Übersicht
            </button>
          </div>
        </div>
      </div>
    )
  }

  const qualityInfo = QUALITY_LEVELS.find(q => q.value === product.quality)

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-6xl">
        {/* Zurück-Button */}
        <button
          onClick={() => router.push('/browse')}
          className="flex items-center text-gray-600 hover:text-primary-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Zurück zur Übersicht
        </button>

        {/* Produktdetails */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Produktbild */}
          <div className="space-y-4">
            <div className="relative">
              <img
                src={product.imageUrl || `https://via.placeholder.com/600x400/3b82f6/ffffff?text=${encodeURIComponent(product.name)}`}
                alt={product.name}
                className="w-full h-96 object-cover rounded-2xl shadow-soft"
              />
              
              {/* Verfügbarkeits-Badge */}
              <div className="absolute top-4 right-4">
                <span className={`px-3 py-2 rounded-full text-sm font-medium ${
                  product.available 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {product.available ? (
                    <span className="flex items-center">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Verfügbar
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <AlertCircle className="w-4 h-4 mr-1" />
                      Nicht verfügbar
                    </span>
                  )}
                </span>
              </div>

              {/* Qualitäts-Badge */}
              <div className="absolute top-4 left-4">
                <span className={`px-3 py-2 rounded-full text-sm font-medium bg-white/90 backdrop-blur-sm ${
                  qualityInfo?.color || 'text-gray-600'
                }`}>
                  {qualityInfo?.label || product.quality}
                </span>
              </div>
            </div>

            {/* Zusätzliche Informationen */}
            <div className="bg-white rounded-2xl shadow-soft p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Produktinformationen</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Produkt-ID:</span>
                  <span className="font-mono text-gray-900">{product.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Erstellt am:</span>
                  <span className="text-gray-900">
                    {new Date(product.createdAt).toLocaleDateString('de-DE')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Kategorie:</span>
                  <span className="text-gray-900">{product.category}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Produktinformationen */}
          <div className="space-y-6">
            {/* Titel und Kategorie */}
            <div>
              <span className="inline-block px-3 py-1 bg-primary-100 text-primary-800 text-sm font-medium rounded-lg mb-3">
                {product.category}
              </span>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {product.name}
              </h1>
              <p className="text-gray-600 text-lg leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Preis und Kaution */}
            <div className="bg-white rounded-2xl shadow-soft p-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary-600 mb-1">
                    €{product.pricePerDay}
                  </div>
                  <div className="text-gray-600">pro Tag</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    €{product.deposit}
                  </div>
                  <div className="text-gray-600">Kaution</div>
                </div>
              </div>
            </div>

            {/* Qualität */}
            <div className="bg-white rounded-2xl shadow-soft p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                <Star className="w-5 h-5 mr-2 text-yellow-500" />
                Qualität
              </h3>
              <div className="flex items-center">
                <span className={`text-lg font-medium ${qualityInfo?.color || 'text-gray-600'}`}>
                  {qualityInfo?.label || product.quality}
                </span>
                <div className="ml-4 flex">
                  {[...Array(3)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < (product.quality === 'gut' ? 1 : product.quality === 'sehr gut' ? 2 : 3)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Verfügbarkeit */}
            <div className="bg-white rounded-2xl shadow-soft p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-primary-600" />
                Verfügbarkeit
              </h3>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Status:</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  product.available 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {product.available ? 'Verfügbar zur Vermietung' : 'Derzeit nicht verfügbar'}
                </span>
              </div>
            </div>

            {/* Aktionen */}
            <div className="space-y-4">
              {product.available ? (
                <button className="btn-primary w-full text-lg py-4">
                  <Package className="w-6 h-6 mr-2" />
                  Jetzt mieten
                </button>
              ) : (
                <button className="btn-secondary w-full text-lg py-4" disabled>
                  <AlertCircle className="w-6 h-6 mr-2" />
                  Nicht verfügbar
                </button>
              )}
              
              <button className="btn-secondary w-full py-3">
                <MapPin className="w-5 h-5 mr-2" />
                Standort anzeigen
              </button>
            </div>
          </div>
        </div>

        {/* Ähnliche Produkte */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Ähnliche Produkte
          </h2>
          <div className="text-center py-12 bg-white rounded-2xl shadow-soft">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Ähnliche Produkte werden bald verfügbar sein
            </h3>
            <p className="text-gray-600 mb-6">
              Wir arbeiten daran, dir ähnliche Produkte zu zeigen.
            </p>
            <button
              onClick={() => router.push('/browse')}
              className="btn-primary"
            >
              Alle Produkte durchsuchen
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
