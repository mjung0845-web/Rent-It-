'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { Search, Plus, Star, TrendingUp, Users, Package } from 'lucide-react'
import { productService } from '../services/api'
import { Product } from '../types/product'

export default function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadFeaturedProducts()
  }, [])

  const loadFeaturedProducts = async () => {
    try {
      setLoading(true)
      const products = await productService.getAllProducts()
      // Zeige die neuesten 6 Produkte
      setFeaturedProducts(products.slice(0, 6))
    } catch (error) {
      console.error('Fehler beim Laden der Produkte:', error)
    } finally {
      setLoading(false)
    }
  }

  // Produkte neu laden, wenn die Seite fokussiert wird
  useEffect(() => {
    const handleFocus = () => {
      loadFeaturedProducts()
    }

    window.addEventListener('focus', handleFocus)
    return () => window.removeEventListener('focus', handleFocus)
  }, [])

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white py-20">
        <div className="container-custom text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
            Willkommen bei <span className="text-yellow-300">RentIt</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-primary-100 max-w-3xl mx-auto animate-fade-in">
            Dein einfacher Marktplatz für Produktvermietung. Entdecke und vermiete Produkte aller Art - 
            von Camping-Ausrüstung bis Werkzeug.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Link href="/browse" className="btn-primary bg-white text-primary-600 hover:bg-gray-100">
              <Search className="w-5 h-5 mr-2" />
              Produkte durchsuchen
            </Link>
            <Link href="/create" className="btn-secondary bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary-600">
              <Plus className="w-5 h-5 mr-2" />
              Produkt erstellen
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-900">
            Warum RentIt?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Package className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Einfach zu bedienen</h3>
              <p className="text-gray-600">
                Erstelle und finde Produkte in wenigen Klicks. Keine komplizierten Anmeldungen erforderlich.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Schnell und effizient</h3>
              <p className="text-gray-600">
                Finde genau das, was du brauchst, oder stelle deine Produkte in Sekunden online.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Community-basiert</h3>
              <p className="text-gray-600">
                Tausche dich mit anderen Nutzern aus und baue eine nachhaltige Sharing-Community auf.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-4xl font-bold text-gray-900">
              Neueste Produkte
            </h2>
            <Link href="/browse" className="btn-primary">
              Alle anzeigen
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card p-6 animate-pulse">
                  <div className="w-full h-48 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : featuredProducts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.map((product) => (
                <Link 
                  key={product.id} 
                  href={`/product/${product.id}`}
                  className="card p-6 hover:shadow-soft-lg transition-all duration-300 group"
                >
                  <div className="relative mb-4">
                    <img
                      src={product.imageUrl || `https://via.placeholder.com/400x300/3b82f6/ffffff?text=${encodeURIComponent(product.name)}`}
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        product.available 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {product.available ? 'Verfügbar' : 'Nicht verfügbar'}
                      </span>
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-lg mb-2 text-gray-900 group-hover:text-primary-600 transition-colors">
                    {product.name}
                  </h3>
                  
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-500">{product.category}</span>
                    <span className="text-sm text-gray-500">{product.quality}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary-600">
                      €{product.pricePerDay}/Tag
                    </span>
                    <span className="text-sm text-gray-500">
                      Kaution: €{product.deposit}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Noch keine Produkte verfügbar
              </h3>
              <p className="text-gray-600 mb-6">
                Sei der Erste und stelle dein Produkt ein!
              </p>
              <Link href="/create" className="btn-primary">
                <Plus className="w-5 h-5 mr-2" />
                Erstes Produkt erstellen
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-600 text-white">
        <div className="container-custom text-center">
          <h2 className="text-4xl font-bold mb-6">
            Bereit, dein Produkt zu vermieten?
          </h2>
          <p className="text-xl mb-8 text-primary-100 max-w-2xl mx-auto">
            Tausende von Menschen suchen nach genau dem, was du anzubieten hast. 
            Erstelle dein Produkt in wenigen Minuten und starte noch heute!
          </p>
          <Link href="/create" className="btn-primary bg-white text-primary-600 hover:bg-gray-100 text-lg px-8 py-4">
            <Plus className="w-6 h-6 mr-2" />
            Jetzt Produkt erstellen
          </Link>
        </div>
      </section>
    </div>
  )
}
