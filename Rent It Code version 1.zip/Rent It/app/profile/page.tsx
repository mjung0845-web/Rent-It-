'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/AuthProvider'
import { motion } from 'framer-motion'
import { User, Mail, MapPin, Calendar, Edit, Save, X } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase'

// Typen für das Profil
interface Profile {
  id: string
  name: string
  email: string
  avatar_url: string | null
  created_at: string
}

export default function ProfilePage() {
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: ''
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Lädt das Profil beim Start
  useEffect(() => {
    if (user) {
      loadProfile()
    }
  }, [user])

  // Überprüft, ob der Benutzer angemeldet ist
  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin')
    }
  }, [user, authLoading, router])

  // Lädt das Benutzerprofil
  const loadProfile = async () => {
    try {
      setLoading(true)
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user!.id)
        .single()

      if (error) throw error
      
      setProfile(data)
      setFormData({
        name: data.name || '',
        email: data.email || ''
      })
    } catch (error) {
      console.error('Fehler beim Laden des Profils:', error)
    } finally {
      setLoading(false)
    }
  }

  // Behandelt Änderungen im Formular
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    setError('')
  }

  // Behandelt das Speichern der Änderungen
  const handleSave = async () => {
    try {
      setSaving(true)
      setError('')

      // Validierung
      if (!formData.name.trim()) {
        throw new Error('Name ist erforderlich')
      }

      // Aktualisiert das Profil
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          name: formData.name.trim()
        })
        .eq('id', user!.id)

      if (updateError) throw updateError

      // Aktualisiert den lokalen Zustand
      setProfile(prev => prev ? { ...prev, name: formData.name.trim() } : null)
      setEditing(false)
      setSuccess('Profil erfolgreich aktualisiert!')
      
      // Löscht die Erfolgsmeldung nach 3 Sekunden
      setTimeout(() => setSuccess(''), 3000)

    } catch (error: any) {
      setError(error.message || 'Ein Fehler ist aufgetreten')
    } finally {
      setSaving(false)
    }
  }

  // Behandelt das Abbrechen der Bearbeitung
  const handleCancel = () => {
    setEditing(false)
    setFormData({
      name: profile?.name || '',
      email: profile?.email || ''
    })
    setError('')
  }

  // Zeigt Ladebildschirm während der Authentifizierung
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  // Zeigt Weiterleitung, wenn nicht angemeldet
  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Mein Profil
          </h1>
          <p className="text-xl text-gray-600">
            Verwalte deine persönlichen Informationen
          </p>
        </motion.div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Lade Profil...</p>
          </div>
        ) : profile ? (
          <div className="space-y-6">
            {/* Profil-Übersicht */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Profil-Übersicht</CardTitle>
                    <Button
                      variant="outline"
                      onClick={() => setEditing(!editing)}
                      className="flex items-center space-x-2"
                    >
                      {editing ? (
                        <>
                          <X className="w-4 h-4" />
                          <span>Abbrechen</span>
                        </>
                      ) : (
                        <>
                          <Edit className="w-4 h-4" />
                          <span>Bearbeiten</span>
                        </>
                      )}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Profilbild */}
                    <div className="text-center">
                      <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        {profile.avatar_url ? (
                          <img
                            src={profile.avatar_url}
                            alt="Profilbild"
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          <User className="w-12 h-12 text-primary-600" />
                        )}
                      </div>
                      <p className="text-sm text-gray-500">
                        Profilbild (noch nicht verfügbar)
                      </p>
                    </div>

                    {/* Profilinformationen */}
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Name
                        </label>
                        {editing ? (
                          <input
                            type="text"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                            placeholder="Dein vollständiger Name"
                          />
                        ) : (
                          <div className="flex items-center space-x-2 px-4 py-3 bg-gray-50 rounded-xl">
                            <User className="w-5 h-5 text-gray-400" />
                            <span className="text-gray-900">{profile.name || 'Nicht angegeben'}</span>
                          </div>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          E-Mail
                        </label>
                        <div className="flex items-center space-x-2 px-4 py-3 bg-gray-50 rounded-xl">
                          <Mail className="w-5 h-5 text-gray-400" />
                          <span className="text-gray-900">{profile.email}</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          E-Mail kann nicht geändert werden
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Mitglied seit
                        </label>
                        <div className="flex items-center space-x-2 px-4 py-3 bg-gray-50 rounded-xl">
                          <Calendar className="w-5 h-5 text-gray-400" />
                          <span className="text-gray-900">
                            {new Date(profile.created_at).toLocaleDateString('de-DE', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Bearbeitungs-Buttons */}
                  {editing && (
                    <div className="flex justify-end space-x-4 mt-6 pt-6 border-t border-gray-200">
                      <Button variant="outline" onClick={handleCancel}>
                        Abbrechen
                      </Button>
                      <Button
                        onClick={handleSave}
                        disabled={saving}
                        className="flex items-center space-x-2"
                      >
                        <Save className="w-4 h-4" />
                        <span>{saving ? 'Wird gespeichert...' : 'Speichern'}</span>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Konto-Einstellungen */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="card-hover">
                <CardHeader>
                  <CardTitle>Konto-Einstellungen</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <h3 className="font-medium text-gray-900">Passwort ändern</h3>
                        <p className="text-sm text-gray-600">
                          Ändere dein Passwort für mehr Sicherheit
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        Ändern
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <h3 className="font-medium text-gray-900">E-Mail-Benachrichtigungen</h3>
                        <p className="text-sm text-gray-600">
                          Verwalte deine E-Mail-Einstellungen
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        Verwalten
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <h3 className="font-medium text-gray-900">Datenschutz</h3>
                        <p className="text-sm text-gray-600">
                          Verwalte deine Datenschutz-Einstellungen
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        Verwalten
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Fehlermeldung */}
            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700"
              >
                {error}
              </motion.div>
            )}

            {/* Erfolgsmeldung */}
            {success && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-green-50 border border-green-200 rounded-xl p-4 text-green-700"
              >
                {success}
              </motion.div>
            )}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">❌</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Profil nicht gefunden
            </h3>
            <p className="text-gray-600 mb-6">
              Dein Profil konnte nicht geladen werden.
            </p>
            <Button onClick={() => loadProfile()}>
              Erneut versuchen
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

