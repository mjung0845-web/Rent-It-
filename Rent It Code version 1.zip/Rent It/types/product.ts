export interface Product {
  id: string;
  name: string;
  category: string;
  pricePerDay: number;
  quality: 'gut' | 'sehr gut' | 'neuwertig';
  deposit: number;
  description?: string;
  imageUrl?: string;
  createdAt: string;
  available: boolean;
}

export interface CreateProductForm {
  name: string;
  category: string;
  pricePerDay: string;
  quality: 'gut' | 'sehr gut' | 'neuwertig';
  deposit: string;
  description: string;
}

export interface ProductFilters {
  category?: string;
  maxPrice?: number;
  quality?: string;
  available?: boolean;
}

export const PRODUCT_CATEGORIES = [
  'Camping',
  'Party',
  'Werkzeug',
  'Sport',
  'Elektronik',
  'Haushalt',
  'Garten',
  'Musik',
  'Fahrzeuge',
  'Sonstiges'
] as const;

export const QUALITY_LEVELS = [
  { value: 'gut', label: 'Gut', color: 'text-green-600' },
  { value: 'sehr gut', label: 'Sehr gut', color: 'text-blue-600' },
  { value: 'neuwertig', label: 'Neuwertig', color: 'text-purple-600' }
] as const;
