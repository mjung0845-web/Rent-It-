-- RentIt Datenbank-Schema
-- Führen Sie diese SQL-Befehle in Ihrem Supabase SQL Editor aus

-- Erstellt die Benutzer-Tabelle mit erweiterten Profilinformationen
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  name TEXT,
  email TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Erstellt die Kategorien-Tabelle für verschiedene Mietgegenstände
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  icon TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Fügt Standard-Kategorien hinzu
INSERT INTO public.categories (name, icon) VALUES
  ('Werkzeuge', '🔧'),
  ('Elektronik', '💻'),
  ('Party & Events', '🎉'),
  ('Fahrzeuge', '🚗'),
  ('Sport & Outdoor', '⚽'),
  ('Haushalt', '🏠'),
  ('Mode & Accessoires', '👕'),
  ('Musik & Instrumente', '🎸'),
  ('Bücher & Medien', '📚'),
  ('Sonstiges', '📦'
) ON CONFLICT (name) DO NOTHING;

-- Erstellt die Gegenstände-Tabelle
CREATE TABLE IF NOT EXISTS public.items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category_id UUID REFERENCES public.categories(id),
  price_per_day DECIMAL(10,2) NOT NULL,
  location TEXT,
  image_url TEXT,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Erstellt die Mietbuchungen-Tabelle
CREATE TABLE IF NOT EXISTS public.rentals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  item_id UUID REFERENCES public.items(id) ON DELETE CASCADE NOT NULL,
  renter_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  owner_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  total_price DECIMAL(10,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Erstellt die Bewertungen-Tabelle
CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  rental_id UUID REFERENCES public.rentals(id) ON DELETE CASCADE NOT NULL,
  reviewer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  reviewed_user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5) NOT NULL,
  comment TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Erstellt Indizes für bessere Performance
CREATE INDEX IF NOT EXISTS idx_items_user_id ON public.items(user_id);
CREATE INDEX IF NOT EXISTS idx_items_category_id ON public.items(category_id);
CREATE INDEX IF NOT EXISTS idx_items_location ON public.items(location);
CREATE INDEX IF NOT EXISTS idx_rentals_item_id ON public.rentals(item_id);
CREATE INDEX IF NOT EXISTS idx_rentals_renter_id ON public.rentals(renter_id);
CREATE INDEX IF NOT EXISTS idx_rentals_owner_id ON public.rentals(owner_id);

-- Erstellt eine Funktion zum Aktualisieren des updated_at Timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Erstellt Trigger für automatische updated_at Aktualisierung
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_items_updated_at BEFORE UPDATE ON public.items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rentals_updated_at BEFORE UPDATE ON public.rentals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Erstellt Row Level Security (RLS) Policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rentals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Profiles: Benutzer können nur ihr eigenes Profil lesen/bearbeiten
CREATE POLICY "Benutzer können ihr eigenes Profil verwalten" ON public.profiles
  FOR ALL USING (auth.uid() = id);

-- Items: Alle können Gegenstände lesen, nur Besitzer können bearbeiten
CREATE POLICY "Alle können Gegenstände lesen" ON public.items
  FOR SELECT USING (true);

CREATE POLICY "Besitzer können ihre Gegenstände verwalten" ON public.items
  FOR ALL USING (auth.uid() = user_id);

-- Rentals: Benutzer können nur ihre eigenen Buchungen sehen
CREATE POLICY "Benutzer können ihre eigenen Buchungen sehen" ON public.rentals
  FOR SELECT USING (auth.uid() = renter_id OR auth.uid() = owner_id);

CREATE POLICY "Benutzer können neue Buchungen erstellen" ON public.rentals
  FOR INSERT WITH CHECK (auth.uid() = renter_id);

-- Reviews: Alle können Bewertungen lesen, nur beteiligte Benutzer können erstellen
CREATE POLICY "Alle können Bewertungen lesen" ON public.reviews
  FOR SELECT USING (true);

CREATE POLICY "Beteiligte Benutzer können Bewertungen erstellen" ON public.reviews
  FOR INSERT WITH CHECK (auth.uid() = reviewer_id);

-- Erstellt eine Funktion zum Erstellen eines Profils nach der Registrierung
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'name', NEW.email);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Erstellt einen Trigger für neue Benutzer
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
