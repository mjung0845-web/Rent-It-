'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, Search, Plus } from 'lucide-react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-soft sticky top-0 z-50">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">R</span>
            </div>
            <span className="text-2xl font-bold text-primary-600">RentIt</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link 
              href="/" 
              className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
            >
              Startseite
            </Link>
            <Link 
              href="/browse" 
              className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
            >
              Produkte durchsuchen
            </Link>
            <Link 
              href="/create" 
              className="text-gray-700 hover:text-primary-600 font-medium transition-colors"
            >
              Produkt erstellen
            </Link>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/browse" className="btn-secondary flex items-center space-x-2">
              <Search className="w-4 h-4" />
              <span>Durchsuchen</span>
            </Link>
            <Link href="/create" className="btn-primary flex items-center space-x-2">
              <Plus className="w-4 h-4" />
              <span>Produkt erstellen</span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6 text-gray-700" />
            ) : (
              <Menu className="w-6 h-6 text-gray-700" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 animate-fade-in">
            <nav className="flex flex-col space-y-4">
              <Link 
                href="/" 
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors px-4 py-2 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Startseite
              </Link>
              <Link 
                href="/browse" 
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors px-4 py-2 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Produkte durchsuchen
              </Link>
              <Link 
                href="/create" 
                className="text-gray-700 hover:text-primary-600 font-medium transition-colors px-4 py-2 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Produkt erstellen
              </Link>
            </nav>
            
            <div className="mt-6 px-4 space-y-3">
              <Link 
                href="/browse" 
                className="btn-secondary w-full flex items-center justify-center space-x-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Search className="w-4 h-4" />
                <span>Durchsuchen</span>
              </Link>
              <Link 
                href="/create" 
                className="btn-primary w-full flex items-center justify-center space-x-2"
                onClick={() => setIsMenuOpen(false)}
              >
                <Plus className="w-4 h-4" />
                <span>Produkt erstellen</span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
