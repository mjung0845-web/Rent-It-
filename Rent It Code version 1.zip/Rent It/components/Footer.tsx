import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo und Beschreibung */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">R</span>
              </div>
              <span className="text-xl font-bold text-white">RentIt</span>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Dein einfacher Marktplatz für Produktvermietung. Entdecke und vermiete Produkte aller Art - 
              von Camping-Ausrüstung bis Werkzeug.
            </p>
          </div>

          {/* Plattform Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Plattform</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/" className="hover:text-primary-400 transition-colors">
                  Startseite
                </Link>
              </li>
              <li>
                <Link href="/browse" className="hover:text-primary-400 transition-colors">
                  Produkte durchsuchen
                </Link>
              </li>
              <li>
                <Link href="/create" className="hover:text-primary-400 transition-colors">
                  Produkt erstellen
                </Link>
              </li>
            </ul>
          </div>

          {/* Kategorien */}
          <div>
            <h4 className="font-semibold text-white mb-4">Kategorien</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/browse?category=Camping" className="hover:text-primary-400 transition-colors">
                  Camping
                </Link>
              </li>
              <li>
                <Link href="/browse?category=Party" className="hover:text-primary-400 transition-colors">
                  Party
                </Link>
              </li>
              <li>
                <Link href="/browse?category=Werkzeug" className="hover:text-primary-400 transition-colors">
                  Werkzeug
                </Link>
              </li>
              <li>
                <Link href="/browse?category=Sport" className="hover:text-primary-400 transition-colors">
                  Sport
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 RentIt. Alle Rechte vorbehalten.</p>
          <p className="text-sm mt-2">
            Einfach. Schnell. Zuverlässig.
          </p>
        </div>
      </div>
    </footer>
  )
}
