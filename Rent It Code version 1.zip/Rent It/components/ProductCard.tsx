import Link from 'next/link'
import { Product, QUALITY_LEVELS } from '../types/product'

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const qualityInfo = QUALITY_LEVELS.find(q => q.value === product.quality)

  return (
    <Link 
      href={`/product/${product.id}`}
      className="card p-6 hover:shadow-soft-lg transition-all duration-300 group block"
    >
      {/* Produktbild */}
      <div className="relative mb-4">
        <img
          src={product.imageUrl || `https://via.placeholder.com/400x300/3b82f6/ffffff?text=${encodeURIComponent(product.name)}`}
          alt={product.name}
          className="w-full h-48 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Verfügbarkeits-Badge */}
        <div className="absolute top-3 right-3">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            product.available 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            {product.available ? 'Verfügbar' : 'Nicht verfügbar'}
          </span>
        </div>

        {/* Qualitäts-Badge */}
        <div className="absolute top-3 left-3">
          <span className={`px-2 py-1 rounded-full text-xs font-medium bg-white/90 backdrop-blur-sm ${
            qualityInfo?.color || 'text-gray-600'
          }`}>
            {qualityInfo?.label || product.quality}
          </span>
        </div>
      </div>

      {/* Produktinformationen */}
      <div className="space-y-3">
        {/* Kategorie */}
        <div className="flex items-center justify-between">
          <span className="inline-block px-2 py-1 bg-primary-100 text-primary-800 text-xs font-medium rounded-lg">
            {product.category}
          </span>
          <span className="text-xs text-gray-500">
            {new Date(product.createdAt).toLocaleDateString('de-DE')}
          </span>
        </div>

        {/* Produktname */}
        <h3 className="font-semibold text-lg text-gray-900 group-hover:text-primary-600 transition-colors line-clamp-2">
          {product.name}
        </h3>

        {/* Beschreibung */}
        {product.description && (
          <p className="text-gray-600 text-sm line-clamp-2">
            {product.description}
          </p>
        )}

        {/* Preis und Kaution */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-100">
          <div>
            <span className="text-2xl font-bold text-primary-600">
              €{product.pricePerDay}
            </span>
            <span className="text-sm text-gray-500">/Tag</span>
          </div>
          <div className="text-right">
            <span className="text-sm text-gray-500">Kaution:</span>
            <div className="font-semibold text-gray-900">
              €{product.deposit}
            </div>
          </div>
        </div>

        {/* Zusätzliche Details */}
        <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100">
          <span>ID: {product.id.slice(-6)}</span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            qualityInfo?.color || 'text-gray-600'
          } bg-gray-100`}>
            {qualityInfo?.label || product.quality}
          </span>
        </div>
      </div>
    </Link>
  )
}
