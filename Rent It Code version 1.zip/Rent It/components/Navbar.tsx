'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useAuth } from './AuthProvider'
import { Button } from './ui/button'
import { Card, CardContent } from './ui/card'
import { 
  Menu, 
  X, 
  User, 
  LogOut, 
  Settings, 
  Home,
  Search,
  Plus,
  UserCircle
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

// Navigationsleiste mit modernem Design und Animationen
export function Navbar() {
  const { user, signOut } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)

  // Schließt alle geöffneten Menüs
  const closeMenus = () => {
    setIsMenuOpen(false)
    setIsProfileOpen(false)
  }

  // Behandelt die Abmeldung
  const handleSignOut = async () => {
    try {
      await signOut()
      closeMenus()
    } catch (error) {
      console.error('Fehler bei der Abmeldung:', error)
    }
  }

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo und Hauptnavigation */}
          <div className="flex items-center space-x-8">
            {/* RentIt Logo */}
            <Link href="/" className="flex items-center space-x-2" onClick={closeMenus}>
              <div className="w-8 h-8 bg-primary-500 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">R</span>
              </div>
              <span className="text-2xl font-bold text-primary-500">RentIt</span>
            </Link>

            {/* Desktop-Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              <Link 
                href="/browse" 
                className="text-gray-600 hover:text-primary-500 transition-colors font-medium"
                onClick={closeMenus}
              >
                Durchsuchen
              </Link>
              <Link 
                href="/list" 
                className="text-gray-600 hover:text-primary-500 transition-colors font-medium"
                onClick={closeMenus}
              >
                Gegenstand einstellen
              </Link>
              {user && (
                <Link 
                  href="/dashboard" 
                  className="text-gray-600 hover:text-primary-500 transition-colors font-medium"
                  onClick={closeMenus}
                >
                  Dashboard
                </Link>
              )}
            </div>
          </div>

          {/* Rechte Seite - Auth-Buttons oder Profil */}
          <div className="flex items-center space-x-4">
            {user ? (
              /* Angemeldeter Benutzer - Profil-Dropdown */
              <div className="relative">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="relative"
                >
                  {user.user_metadata?.avatar_url ? (
                    <img
                      src={user.user_metadata.avatar_url}
                      alt="Profilbild"
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <UserCircle className="w-6 h-6" />
                  )}
                </Button>

                {/* Profil-Dropdown */}
                <AnimatePresence>
                  {isProfileOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 mt-2 w-48"
                    >
                      <Card className="shadow-soft-lg">
                        <CardContent className="p-2">
                          <div className="px-3 py-2 border-b border-gray-100">
                            <p className="text-sm font-medium text-gray-900">
                              {user.user_metadata?.name || 'Benutzer'}
                            </p>
                            <p className="text-xs text-gray-500">{user.email}</p>
                          </div>
                          
                          <div className="py-1">
                            <Link
                              href="/dashboard"
                              className="flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                              onClick={closeMenus}
                            >
                              <User className="w-4 h-4 mr-2" />
                              Dashboard
                            </Link>
                            <Link
                              href="/profile"
                              className="flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                              onClick={closeMenus}
                            >
                              <Settings className="w-4 h-4 mr-2" />
                              Profil
                            </Link>
                            <button
                              onClick={handleSignOut}
                              className="flex items-center w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <LogOut className="w-4 h-4 mr-2" />
                              Abmelden
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              /* Nicht angemeldet - Login/Register Buttons */
              <div className="hidden md:flex items-center space-x-3">
                <Link href="/auth/signin">
                  <Button variant="outline" size="sm">
                    Anmelden
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button size="sm">
                    Registrieren
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile-Menü-Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile-Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden border-t border-gray-200"
            >
              <div className="py-4 space-y-3">
                <Link
                  href="/browse"
                  className="flex items-center px-4 py-2 text-gray-600 hover:text-primary-500 hover:bg-gray-50 rounded-lg transition-colors"
                  onClick={closeMenus}
                >
                  <Search className="w-5 h-5 mr-3" />
                  Durchsuchen
                </Link>
                <Link
                  href="/list"
                  className="flex items-center px-4 py-2 text-gray-600 hover:text-primary-500 hover:bg-gray-50 rounded-lg transition-colors"
                  onClick={closeMenus}
                >
                  <Plus className="w-5 h-5 mr-3" />
                  Gegenstand einstellen
                </Link>
                {user && (
                  <Link
                    href="/dashboard"
                    className="flex items-center px-4 py-2 text-gray-600 hover:text-primary-500 hover:bg-gray-50 rounded-lg transition-colors"
                    onClick={closeMenus}
                  >
                    <User className="w-5 h-5 mr-3" />
                    Dashboard
                  </Link>
                )}
                {!user && (
                  <div className="px-4 space-y-3 pt-4 border-t border-gray-200">
                    <Link href="/auth/signin" onClick={closeMenus}>
                      <Button variant="outline" className="w-full">
                        Anmelden
                      </Button>
                    </Link>
                    <Link href="/auth/signup" onClick={closeMenus}>
                      <Button className="w-full">
                        Registrieren
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  )
}
