'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'

// Typen für den Auth-Kontext
interface AuthContextType {
  user: User | null
  session: Session | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string) => Promise<void>
  signOut: () => Promise<void>
  signInWithGoogle: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
}

// Erstellt den Auth-Kontext
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// AuthProvider-Komponente für die gesamte Anwendung
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  // Lädt die initiale Session beim Start der Anwendung
  useEffect(() => {
    const getInitialSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        setSession(session)
        setUser(session?.user ?? null)
      } catch (error) {
        console.error('Fehler beim Laden der Session:', error)
      } finally {
        setLoading(false)
      }
    }

    getInitialSession()

    // Hört auf Auth-Änderungen (Login, Logout, etc.)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session)
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    // Cleanup der Subscription
    return () => subscription.unsubscribe()
  }, [])

  // Anmeldung mit E-Mail und Passwort
  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      if (error) throw error
    } catch (error) {
      console.error('Fehler bei der Anmeldung:', error)
      throw error
    }
  }

  // Registrierung mit E-Mail, Passwort und Name
  const signUp = async (email: string, password: string, name: string) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
          },
        },
      })
      if (error) throw error
    } catch (error) {
      console.error('Fehler bei der Registrierung:', error)
      throw error
    }
  }

  // Abmeldung
  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) throw error
    } catch (error) {
      console.error('Fehler bei der Abmeldung:', error)
      throw error
    }
  }

  // Anmeldung mit Google
  const signInWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })
      if (error) throw error
    } catch (error) {
      console.error('Fehler bei der Google-Anmeldung:', error)
      throw error
    }
  }

  // Passwort zurücksetzen
  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })
      if (error) throw error
    } catch (error) {
      console.error('Fehler beim Zurücksetzen des Passworts:', error)
      throw error
    }
  }

  // Wert für den Auth-Kontext
  const value: AuthContextType = {
    user,
    session,
    loading,
    signIn,
    signUp,
    signOut,
    signInWithGoogle,
    resetPassword,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

// Hook zum Verwenden des Auth-Kontexts
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth muss innerhalb eines AuthProviders verwendet werden')
  }
  return context
}
