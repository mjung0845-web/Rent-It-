# 🚀 Deployment-Anleitung für RentIt

Diese Anleitung führt Sie Schritt für Schritt durch das Deployment Ihrer RentIt-Webapp auf Vercel mit Supabase als Backend.

## 📋 Voraussetzungen

- GitHub-Konto
- Vercel-Konto (kostenlos)
- Supabase-Konto (kostenlos)
- Node.js 18+ auf Ihrem lokalen System

## 🔧 Schritt 1: Supabase-Projekt einrichten

### 1.1 Supabase-Projekt erstellen

1. Gehen Sie zu [supabase.com](https://supabase.com)
2. Klicken Sie auf "Start your project"
3. Wählen Sie "New Project"
4. Wählen Sie Ihre Organisation oder erstellen Sie eine neue
5. Geben Sie einen Projektnamen ein (z.B. "rentit-production")
6. Wählen Sie ein Datenbankpasswort (notieren Sie es!)
7. Wählen Sie eine Region (am besten nahe Ihren Nutzern)
8. Klicken Sie auf "Create new project"

### 1.2 Datenbank-Schema einrichten

1. Warten Sie, bis das Projekt erstellt ist (ca. 2-3 Minuten)
2. Gehen Sie zu "SQL Editor" im linken Menü
3. Klicken Sie auf "New query"
4. Kopieren Sie den gesamten Inhalt aus `supabase/schema.sql`
5. Führen Sie das Skript aus (Klick auf "Run")
6. Überprüfen Sie, dass alle Tabellen erstellt wurden

### 1.3 API-Schlüssel kopieren

1. Gehen Sie zu "Settings" → "API"
2. Kopieren Sie:
   - **Project URL** (z.B. `https://abc123.supabase.co`)
   - **anon public** key
   - **service_role** key (für Admin-Funktionen)

## 🔧 Schritt 2: Lokales Projekt vorbereiten

### 2.1 Repository klonen/erstellen

```bash
# Falls Sie das Repository noch nicht haben
git clone <ihr-repository-url>
cd rentit

# Oder falls Sie ein neues Repository erstellen
mkdir rentit
cd rentit
git init
```

### 2.2 Abhängigkeiten installieren

```bash
npm install
```

### 2.3 Umgebungsvariablen konfigurieren

Erstellen Sie eine `.env.local` Datei:

```env
NEXT_PUBLIC_SUPABASE_URL=https://ihre-projekt-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=ihr-anon-key
SUPABASE_SERVICE_ROLE_KEY=ihr-service-role-key
```

### 2.4 Lokalen Server testen

```bash
npm run dev
```

Öffnen Sie [http://localhost:3000](http://localhost:3000) und testen Sie:
- Landing Page lädt
- Registrierung funktioniert
- Anmeldung funktioniert

## 🔧 Schritt 3: GitHub-Repository einrichten

### 3.1 Code committen

```bash
git add .
git commit -m "Initial commit: RentIt Webapp"
git branch -M main
git remote add origin <ihr-github-repo-url>
git push -u origin main
```

### 3.2 Repository-Einstellungen

1. Gehen Sie zu Ihrem GitHub-Repository
2. Stellen Sie sicher, dass es öffentlich ist (für kostenlosen Vercel-Plan)
3. Überprüfen Sie, dass alle Dateien hochgeladen wurden

## 🔧 Schritt 4: Vercel-Deployment

### 4.1 Vercel-Konto erstellen

1. Gehen Sie zu [vercel.com](https://vercel.com)
2. Klicken Sie auf "Sign Up"
3. Wählen Sie "Continue with GitHub"
4. Autorisieren Sie Vercel für Ihr GitHub-Konto

### 4.2 Projekt importieren

1. Klicken Sie auf "New Project"
2. Wählen Sie Ihr GitHub-Repository aus
3. Klicken Sie auf "Import"

### 4.3 Projekt konfigurieren

**Framework Preset**: Next.js (sollte automatisch erkannt werden)

**Build and Output Settings**:
- Build Command: `npm run build` (Standard)
- Output Directory: `.next` (Standard)
- Install Command: `npm install` (Standard)

**Root Directory**: `/` (Standard)

### 4.4 Umgebungsvariablen setzen

Klicken Sie auf "Environment Variables" und fügen Sie hinzu:

```
NEXT_PUBLIC_SUPABASE_URL
https://ihre-projekt-id.supabase.co

NEXT_PUBLIC_SUPABASE_ANON_KEY
ihr-anon-key

SUPABASE_SERVICE_ROLE_KEY
ihr-service-role-key
```

**Wichtig**: Alle Variablen mit `NEXT_PUBLIC_` werden im Browser verfügbar gemacht.

### 4.5 Deployment starten

1. Klicken Sie auf "Deploy"
2. Warten Sie 2-3 Minuten für den Build
3. Notieren Sie sich Ihre Vercel-URL (z.B. `https://rentit.vercel.app`)

## 🔧 Schritt 5: Supabase-Produktionseinstellungen

### 5.1 Domain-Whitelist

1. Gehen Sie zurück zu Supabase
2. Gehen Sie zu "Settings" → "Auth"
3. Fügen Sie Ihre Vercel-URL zur "Site URL" hinzu
4. Fügen Sie `https://ihre-app.vercel.app/auth/callback` zu "Redirect URLs" hinzu

### 5.2 E-Mail-Einstellungen (Optional)

1. Gehen Sie zu "Settings" → "Auth" → "Email Templates"
2. Passen Sie die E-Mail-Templates an (Logo, Farben, Text)
3. Testen Sie die E-Mail-Funktionalität

### 5.3 Storage-Bucket erstellen

1. Gehen Sie zu "Storage" im linken Menü
2. Klicken Sie auf "New Bucket"
3. Name: `item-images`
4. Public bucket aktivieren
5. RLS aktivieren

## 🔧 Schritt 6: Finale Tests

### 6.1 Funktionalität testen

Testen Sie auf Ihrer Live-URL:
- [ ] Landing Page lädt
- [ ] Registrierung funktioniert
- [ ] E-Mail-Bestätigung wird gesendet
- [ ] Anmeldung funktioniert
- [ ] Dashboard ist zugänglich
- [ ] Gegenstände können eingestellt werden
- [ ] Bilder werden hochgeladen

### 6.2 Performance testen

1. Verwenden Sie [PageSpeed Insights](https://pagespeed.web.dev/)
2. Überprüfen Sie Mobile-Performance
3. Testen Sie auf verschiedenen Geräten

## 🔧 Schritt 7: Custom Domain (Optional)

### 7.1 Domain hinzufügen

1. Gehen Sie zu Vercel → Ihr Projekt → "Settings"
2. Klicken Sie auf "Domains"
3. Fügen Sie Ihre Domain hinzu
4. Folgen Sie den DNS-Anweisungen

### 7.2 SSL-Zertifikat

Vercel stellt automatisch SSL-Zertifikate bereit.

## 🔧 Schritt 8: Monitoring und Wartung

### 8.1 Vercel Analytics

1. Aktivieren Sie Vercel Analytics
2. Überwachen Sie Performance-Metriken
3. Setzen Sie Alerts für Fehler

### 8.2 Supabase Monitoring

1. Überwachen Sie Datenbank-Performance
2. Überprüfen Sie Auth-Logs
3. Überwachen Sie Storage-Nutzung

## 🚨 Häufige Probleme und Lösungen

### Problem: Build-Fehler in Vercel
**Lösung**: 
- Überprüfen Sie die Node.js-Version (sollte 18+ sein)
- Stellen Sie sicher, dass alle Abhängigkeiten in `package.json` stehen

### Problem: Supabase-Verbindung funktioniert nicht
**Lösung**:
- Überprüfen Sie die Umgebungsvariablen in Vercel
- Stellen Sie sicher, dass die Supabase-URL korrekt ist
- Überprüfen Sie die RLS-Policies

### Problem: Bilder werden nicht angezeigt
**Lösung**:
- Überprüfen Sie die Storage-Bucket-Einstellungen
- Stellen Sie sicher, dass der Bucket öffentlich ist
- Überprüfen Sie die RLS-Policies für Storage

### Problem: E-Mail-Bestätigung funktioniert nicht
**Lösung**:
- Überprüfen Sie die Redirect-URLs in Supabase
- Testen Sie mit einer gültigen E-Mail-Adresse
- Überprüfen Sie den Spam-Ordner

## 📊 Kostenübersicht

### Vercel (Hobby-Plan)
- **Kosten**: Kostenlos
- **Limits**: 
  - 100GB Bandbreite/Monat
  - 100 Serverless Function Executions/Tag
  - 100GB Storage

### Supabase (Free-Plan)
- **Kosten**: Kostenlos
- **Limits**:
  - 500MB Datenbank
  - 1GB Bandbreite
  - 50MB Datei-Storage
  - 50.000 Auth-Requests/Monat

## 🔄 Updates und Wartung

### Automatische Deployments
- Jeder Push zu `main` löst automatisch ein neues Deployment aus
- Vercel erstellt automatisch Preview-Deployments für Pull Requests

### Datenbank-Updates
1. Ändern Sie das Schema in `supabase/schema.sql`
2. Führen Sie die Änderungen in Supabase aus
3. Testen Sie lokal
4. Committen und pushen Sie die Änderungen

### Abhängigkeiten aktualisieren
```bash
npm update
npm audit fix
git add package*.json
git commit -m "Update dependencies"
git push
```

## 🎉 Glückwunsch!

Ihre RentIt-Webapp ist jetzt live und einsatzbereit! 

**Nächste Schritte:**
1. Testen Sie alle Funktionen gründlich
2. Laden Sie Freunde und Familie zum Testen ein
3. Sammeln Sie Feedback und verbessern Sie die App
4. Überwachen Sie die Performance und Nutzung
5. Planen Sie neue Features basierend auf Nutzerfeedback

**Support:**
- Vercel: [vercel.com/docs](https://vercel.com/docs)
- Supabase: [supabase.com/docs](https://supabase.com/docs)
- Next.js: [nextjs.org/docs](https://nextjs.org/docs)

Viel Erfolg mit Ihrer neuen Mietplattform! 🚀

