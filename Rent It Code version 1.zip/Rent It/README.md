# RentIt - Marktplatz für Produktvermietung

Eine einfache, moderne Web-App für die Vermietung von Produkten aller Art. Von Camping-Ausrüstung bis Werkzeug - alles was du brauchst!

## 🚀 Features

- **Produktdurchsicht**: Alle verfügbaren Produkte in einer übersichtlichen Grid-Ansicht
- **Produkt erstellen**: Einfaches Formular zum Hinzufügen neuer Produkte
- **Detaillierte Produktansicht**: Vollständige Informationen zu jedem Produkt
- **Erweiterte Suche**: Nach Kategorie, Preis, Qualität und Verfügbarkeit filtern
- **Responsive Design**: Funktioniert perfekt auf Desktop und Mobile
- **Keine Anmeldung erforderlich**: Einfach und schnell zu nutzen

## 🛠️ Technologie-Stack

- **Frontend**: Next.js 14 mit React 18
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Datenbank**: JSONbin.io (mit localStorage Fallback)
- **Sprache**: TypeScript
- **Deployment**: Vercel-ready

## 📋 Voraussetzungen

- Node.js 18+ 
- npm oder yarn

## 🚀 Schnellstart

### 1. Repository klonen
```bash
git clone <repository-url>
cd rentit-marketplace
```

### 2. Abhängigkeiten installieren
```bash
npm install
```

### 3. Entwicklungsserver starten
```bash
npm run dev
```

### 4. Im Browser öffnen
Öffne [http://localhost:3000](http://localhost:3000) in deinem Browser.

## 🔧 Konfiguration

### JSONbin.io Setup (Optional)

Für die Online-Speicherung der Produkte:

1. Gehe zu [jsonbin.io](https://jsonbin.io)
2. Erstelle ein kostenloses Konto
3. Erstelle einen neuen Bin
4. Kopiere die Bin-ID und den Master-Key
5. Aktualisiere die Datei `services/api.ts`:

```typescript
const BIN_ID = 'deine-bin-id-hier'
const MASTER_KEY = 'dein-master-key-hier'
```

**Hinweis**: Ohne JSONbin.io wird localStorage als Fallback verwendet.

## 📁 Projektstruktur

```
rentit-marketplace/
├── app/                    # Next.js App Router
│   ├── browse/            # Produktdurchsicht
│   ├── create/            # Produkt erstellen
│   ├── product/[id]/      # Produktdetails
│   ├── globals.css        # Globale Styles
│   ├── layout.tsx         # Hauptlayout
│   └── page.tsx           # Startseite
├── components/             # React-Komponenten
│   ├── Header.tsx         # Navigation
│   ├── Footer.tsx         # Footer
│   └── ProductCard.tsx    # Produktkarte
├── services/               # API-Services
│   └── api.ts             # Produkt-API
├── types/                  # TypeScript-Typen
│   └── product.ts         # Produkt-Interfaces
├── package.json            # Abhängigkeiten
├── tailwind.config.js      # Tailwind-Konfiguration
└── next.config.js          # Next.js-Konfiguration
```

## 🎨 Design-System

### Farben
- **Primary**: Blau (#3b82f6)
- **Gray**: Verschiedene Grautöne
- **Success**: Grün (#10b981)
- **Error**: Rot (#ef4444)

### Komponenten
- **Buttons**: `btn-primary`, `btn-secondary`
- **Cards**: `card` mit Hover-Effekten
- **Inputs**: `input-field`, `select-field`
- **Shadows**: `shadow-soft`, `shadow-soft-lg`

### Animationen
- **Fade In**: `animate-fade-in`
- **Slide Up**: `animate-slide-up`
- **Hover Effects**: Sanfte Übergänge und Transformationen

## 📱 Seiten und Routen

### `/` - Startseite
- Hero-Sektion mit CTA-Buttons
- Features-Übersicht
- Neueste Produkte
- Call-to-Action

### `/browse` - Produktdurchsicht
- Suchfunktion
- Erweiterte Filter (Kategorie, Preis, Qualität)
- Sortierung (Preis, Datum, Name)
- Responsive Grid-Ansicht

### `/create` - Produkt erstellen
- Formular für neue Produkte
- Validierung aller Pflichtfelder
- Erfolgsmeldung und Weiterleitung

### `/product/[id]` - Produktdetails
- Vollständige Produktinformationen
- Großes Produktbild
- Preis und Kaution
- Verfügbarkeitsstatus

## 🔒 Sicherheit

- **Client-seitige Validierung**: Alle Eingaben werden validiert
- **XSS-Schutz**: Sichere HTML-Ausgabe
- **Keine sensiblen Daten**: Keine Benutzerdaten oder Passwörter

## 🚀 Deployment

### Vercel (Empfohlen)

1. Verbinde dein GitHub-Repository mit Vercel
2. Wähle das Repository aus
3. Vercel erkennt automatisch Next.js
4. Deploy!

### Manuelles Deployment

```bash
npm run build
npm run start
```

## 🧪 Entwicklung

### Verfügbare Scripts

```bash
npm run dev          # Entwicklungsserver
npm run build        # Produktions-Build
npm run start        # Produktions-Server
npm run lint         # Code-Linting
```

### Code-Struktur

- **Komponenten**: Wiederverwendbare UI-Komponenten
- **Services**: API-Logik und Datenverwaltung
- **Types**: TypeScript-Interfaces und Typen
- **Styles**: Tailwind CSS-Klassen und Custom CSS

## 🤝 Beitragen

1. Fork das Repository
2. Erstelle einen Feature-Branch
3. Committe deine Änderungen
4. Push zum Branch
5. Erstelle einen Pull Request

## 📄 Lizenz

MIT License - siehe [LICENSE](LICENSE) Datei für Details.

## 🆘 Support

Bei Fragen oder Problemen:

1. Überprüfe die [Issues](https://github.com/username/rentit-marketplace/issues)
2. Erstelle ein neues Issue mit detaillierter Beschreibung
3. Kontaktiere das Entwicklungsteam

## 🔄 Updates

### Version 1.0.0
- ✅ Grundlegende Produktverwaltung
- ✅ Such- und Filterfunktionen
- ✅ Responsive Design
- ✅ JSONbin.io Integration
- ✅ TypeScript-Unterstützung

### Geplante Features
- [ ] Benutzerkonten und Authentifizierung
- [ ] Bewertungssystem
- [ ] Chat-Funktionalität
- [ ] Zahlungsabwicklung
- [ ] Push-Benachrichtigungen

---

**Entwickelt mit ❤️ für die Sharing Economy**
