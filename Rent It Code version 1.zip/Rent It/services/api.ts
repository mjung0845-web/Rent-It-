import { Product, CreateProductForm } from '../types/product';

// Lokale Speicherung im localStorage
const STORAGE_KEY = 'rentit-products';

class ProductService {
  private getProductsFromLocalStorage(): Product[] {
    if (typeof window === 'undefined') return [];
    
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Fehler beim Lesen aus localStorage:', error);
      return [];
    }
  }

  private saveProductsToLocalStorage(products: Product[]): void {
    if (typeof window === 'undefined') return;
    
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    } catch (error) {
      console.error('Fehler beim Speichern in localStorage:', error);
    }
  }

  async getAllProducts(): Promise<Product[]> {
    return this.getProductsFromLocalStorage();
  }

  async createProduct(productData: CreateProductForm): Promise<Product> {
    const products = await this.getAllProducts();
    
    const newProduct: Product = {
      id: Date.now().toString(),
      name: productData.name,
      category: productData.category,
      pricePerDay: parseFloat(productData.pricePerDay),
      quality: productData.quality,
      deposit: parseFloat(productData.deposit),
      description: productData.description,
      imageUrl: `https://via.placeholder.com/400x300/3b82f6/ffffff?text=${encodeURIComponent(productData.name)}`,
      createdAt: new Date().toISOString(),
      available: true,
    };

    products.push(newProduct);
    this.saveProductsToLocalStorage(products);
    
    return newProduct;
  }

  async getProductById(id: string): Promise<Product | null> {
    const products = await this.getAllProducts();
    return products.find(p => p.id === id) || null;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
    const products = await this.getAllProducts();
    const index = products.findIndex(p => p.id === id);
    
    if (index === -1) return null;
    
    products[index] = { ...products[index], ...updates };
    this.saveProductsToLocalStorage(products);
    
    return products[index];
  }

  async deleteProduct(id: string): Promise<boolean> {
    const products = await this.getAllProducts();
    const filteredProducts = products.filter(p => p.id !== id);
    
    if (filteredProducts.length === products.length) return false;
    
    this.saveProductsToLocalStorage(filteredProducts);
    return true;
  }

  async searchProducts(query: string, filters?: any): Promise<Product[]> {
    let products = await this.getAllProducts();
    
    // Text-Suche
    if (query) {
      const searchTerm = query.toLowerCase();
      products = products.filter(p => 
        p.name.toLowerCase().includes(searchTerm) ||
        p.description?.toLowerCase().includes(searchTerm) ||
        p.category.toLowerCase().includes(searchTerm)
      );
    }
    
    // Filter anwenden
    if (filters) {
      if (filters.category) {
        products = products.filter(p => p.category === filters.category);
      }
      if (filters.maxPrice) {
        products = products.filter(p => p.pricePerDay <= filters.maxPrice);
      }
      if (filters.quality) {
        products = products.filter(p => p.quality === filters.quality);
      }
      if (filters.available !== undefined) {
        products = products.filter(p => p.available === filters.available);
      }
    }
    
    return products;
  }
}

export const productService = new ProductService();
